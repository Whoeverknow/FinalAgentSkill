# Session Registry
> One line per session. Loaded at startup (~2K tokens per Art. X).

## Session Naming Convention
`{Role}-{Seq}-{YYYYMMDD}` (e.g., 文本处理-999999999-20260530)

## Active Sessions — *(awaiting first session)*
## Archived — *None*
