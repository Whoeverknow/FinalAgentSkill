# Persistent Memory Registry
> Hot + warm memory index. Loaded at startup (~2K tokens per Art. X).

## Hot Tier
| Memory | File | Type | Last Referenced |
|--------|------|------|:---:|
| *(awaiting first memory)* | — | — | — |

## Warm Tier — *None*
## Archive — *None*
