# Figures Registry
> Per [CONSTITUTION.md](../../tools/CONSTITUTION.md) Article V

| Class | Criteria | Action |
|-------|----------|--------|
| A — Stable | DOI/ISBN/arXiv | Source + figure number only |
| B — Ephemeral | Web/screenshot/rare book | Create entry in `figures/{YYYY}-{MM}/` |
