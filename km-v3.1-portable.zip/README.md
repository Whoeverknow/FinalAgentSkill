# Academic Knowledge Manager v3.1 — Portable Bootstrap

Complete, self-contained knowledge management system. Copy to any computer, point Cowork workspace here, ready.

## Contents
- `tools/` — CONSTITUTION + WORKFLOW + STRATEGY + indices + activity.log + SKILL-BOOTSTRAP + SCHEDULED-TASKS
- `tools/design/` — Architecture docs (CONVERSATION-WIKI, MEMORY-WIKI, SYSTEM-DESIGN, FRACTAL-AUDIT)
- `work/` — Draft staging + papers/
- `knowledge/` — Published library (1 Hello World format reference entry)
- `conversations/` — Session wiki
- `memory/` — Persistent memory
- `baseline/` — Constitution v3.1 snapshot

## Quick Start
1. Copy this folder to any location
2. Point Cowork workspace to this folder → skill auto-activates (path-agnostic detection)
3. Optionally import skill from tools/SKILL-BOOTSTRAP.md
4. Optionally create scheduled tasks from tools/SCHEDULED-TASKS.md

## Path-Agnostic
The skill detects the knowledge base by presence of `tools/CONSTITUTION.md` + `tools/CACHE.md`. No hardcoded paths anywhere.

## Architecture
Three layers: CONSTITUTION (immutable rules I–XII) + WORKFLOW (fixed procedures W1–W8) + STRATEGY (heuristics S1–S11)
Four subsystems: knowledge entries | conversations | memory | figures

## Clean Start
Delete knowledge/2026/05.md (the Hello World entry), reset INDEX.md/CACHE.md/SUMMARIES.md to zero.

Built: 2026-05-30 | Constitution v3.1
