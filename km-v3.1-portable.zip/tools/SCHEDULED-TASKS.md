# Scheduled Task Definitions

## daily-knowledge-review
**Schedule:** `0 3 * * *`
**Description:** 每日03:00自动复盘+GC
**Prompt:** Read tools/CACHE.md, tools/INDEX.md, work/INDEX.md, knowledge/{YYYY}/{MM}.md. Gap analysis. Stale drafts >7d → #st-stale → tombstone. Write to tools/analysis/daily/{YYYY}/{MM}/{YYYY}-{MM}-{DD}.md. Append to activity.log.

## weekly-knowledge-analysis
**Schedule:** `0 10 * * 6`
**Description:** 每周深度分析+lint+治疗(S10)
**Prompt:** Read tools/CONSTITUTION.md, tools/WORKFLOW.md W4, tools/STRATEGY.md S10. Trend+relationship+graph+gap. 6-pathology lint: contradiction/index integrity/expired status/orphans/SUMMARIES gap/stale GC. Auto-fix or flag per S10. Write to tools/analysis/weekly/{YYYY}/{YYYY}-W{WW}-analysis.md with ## Remediation Actions section. Update indices + activity.log.
