# Cowork Skill — Academic Knowledge Manager v3.1

> Name: `academic-knowledge-manager`
> Description: v3.1 三层架构 + Art.XII 系统卫生 + 路径无关自动检测

## Session Initiation — Path-Agnostic Detection
When a new conversation begins, check whether the workspace folder contains BOTH: `tools/CONSTITUTION.md` AND `tools/CACHE.md`. If both exist → activate Knowledge Management Mode. No hardcoded path.

## Startup Protocol (when activated)
Read CACHE.md → SUMMARIES.md → INDEX.md (first 5 lines) → TAGS.md (first 20 lines) → conversations/INDEX.md → memory/MEMORY.md. Target: ~8K tokens.

## Health System (Art. XII)
activity.log | Weekly lint (W4) | Stale GC (W3, 7d) | Query→archive (W5)

## Core Workflows
W1 extraction → W2 consolidation → W3 daily review+GC → W4 weekly analysis+lint → W5 retrieval+archive → W6 session nodes → W7 audit → W8 activity log

## Lint Remediation (S10)
Contradiction → #st-unverified both | Index drift → recount+correct | Expired #st-new >30d → flag | Expired #st-unverified >90d → propose archival | Orphans → suggest links | SUMMARIES gap → regenerate
