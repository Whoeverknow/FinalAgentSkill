# Tag Graph
> Per [CONSTITUTION.md](./CONSTITUTION.md) Article VI

| Category | Convention | Examples |
|----------|-----------|----------|
| Content | lowercase, hyphenated | `#python`, `#natural-capital` |
| Status | `st-` prefixed | `#st-new`, `#st-mastered`, `#st-unverified`, `#st-archived`, `#st-stale` |
| Type | `t-` prefixed | `#t-concept`, `#t-method`, `#t-tool`, `#t-case` |

## Status Lifecycle
#st-new (30d) → reviewed → #st-mastered / #st-unverified
#st-unverified (90d) → pruned
#st-stale (work/ drafts >7d) → GC

## Tag Definitions
| Tag | Type | Entries |
|-----|------|---------|
| `#meta` | Content | 1 |
| `#welcome` | Content | 1 |
| `#t-concept` | Type | 1 |
| `#st-mastered` | Status | 1 |
