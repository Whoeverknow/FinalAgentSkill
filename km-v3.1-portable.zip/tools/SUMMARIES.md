# Entry Summaries
> One line per published entry. Fetch full entry from `knowledge/` on demand.

- P0-IDEA-HELO-0000000001 | Hello World — First Knowledge Entry | P0 | `#meta` `#welcome` | Format reference: demonstrates standard entry schema. (init)
