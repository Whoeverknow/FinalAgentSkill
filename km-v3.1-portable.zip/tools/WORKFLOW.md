# Workflow: Operational Procedures

> **Version**: 3.1 | **Effective**: 2026-05-30
> **Role**: Fixed operational procedures for the Steward. Immutable governance rules → `CONSTITUTION.md`. Heuristics → `STRATEGY.md`.
> This document SHALL NOT contain strategy tables, heuristics, or context-dependent decision rules.

---

## W1: Extraction (Real-Time)

**Trigger**: Scholar signals "save this", uploads a document, or Steward detects knowledge-worthy passage.

**One-pass exhaustive extraction principle**: Material appears only once. Extract fully in this single pass — structure, data, methods, sources, cross-connections. Token cost is high; storage is cheap; material will not return.

**Procedure**:

1. **Confirm intent** with the Scholar.

2. **For uploaded files**: read the full document; do NOT skim or sample.

3. **Extract comprehensively**: problem framing, model architecture, data sources, key equations, quantitative results, limitations, connections to existing knowledge.

4. **If bibliographic information is incomplete**: note it (`**Note**: 引文残缺 — {details}`) but extract content anyway.

5. **Determine next hex serial via state cache**:
   a. Read `tools/CACHE.md` → extract `last_hex_serial`.
   b. Read first 5 lines of `tools/INDEX.md` → verify `total_entries`.
   c. If cache matches → use `last_hex_serial + 1`.
   d. If cache does NOT match → full INDEX.md read to find actual latest KNID.

6. **Assign priority, tags, sources**.

7. **Scan existing entries** for relationships (check TAGS.md and GRAPH.md timestamps; re-read only if stale).

8. **Write full entry** to `work/{YYYY}/{MM}.md` (draft).

9. **Register in `work/INDEX.md`** — add one line: `KNID | Title | #status | date`.

10. **If figure cited and Class B**: create entry in `work/figures/{YYYY}-{MM}/`.

11. **Update `tools/CACHE.md`**: new `last_hex_serial`, new `total_entries`, current timestamp.

12. **Log to audit**: write one line to `tools/audit/logs/{YYYY}-{MM}-audit.log`.

---

## W2: Session-End Review & Consolidation

**Trigger**: Scholar says "检查一下", "整理一下", "回顾", or session naturally concludes.

**Phase A — Session knowledge review (confirmation, not gap-filling)**:
1. Scan the current conversation for **meta-knowledge** — insights about the knowledge itself, connections between entries, critiques, research directions.
2. Note items where extraction encountered uncertainty; flag for Scholar correction.
3. Present findings to Scholar for confirmation.

**Phase B — Daily consolidation**:
1. Read all draft entries from `work/{YYYY}/{MM}.md`.
2. Verify format compliance (Art. IV), including GB/T 7714-2015 citation completeness.
3. Fill missing relational links against published entries in `knowledge/`.
4. Merge near-duplicates (older KNID retained; younger retired with tombstone).
5. **Promote**: append verified entries to `knowledge/{YYYY}/{MM}.md`.
6. Remove promoted entries from `work/{YYYY}/{MM}.md`.
7. Update `work/INDEX.md` — remove promoted entries, mark merged entries.
8. Promote figure entries from `work/figures/` to `knowledge/figures/`.
9. Update `tools/INDEX.md` statistics, `tools/TAGS.md`, `tools/GRAPH.md`.
10. **Update `tools/SUMMARIES.md`**: add/update one-line summaries for all newly promoted entries.
11. **Append to `tools/activity.log`**: `[{timestamp}] consolidate | N entries promoted | KNIDs: X, Y, Z`.
12. Log consolidation to audit.

---

## W3: Daily Automated Review (03:00)

**Procedure**:
1. Scan draft entries in `work/` and entries added to `knowledge/` since previous review.
2. For each entry, identify: referenced concepts without own entry, referenced literature without source entry, unlinked cross-connections.
3. **Append-only policy**: NEVER delete, modify, or overwrite any existing entry. MAY create new draft entries for high-confidence gaps.
4. Write daily review log to `tools/analysis/daily/{YYYY}/{MM}/{YYYY}-{MM}-{DD}.md`.
5. If no activity detected, log "No activity" and exit.
6. **Stale draft GC**: Check `work/INDEX.md` for drafts older than 7 days. For each: flag `#st-stale` in `work/INDEX.md`, remove from active `work/{YYYY}/{MM}.md`, create tombstone in `work/INDEX.md` (metadata-only: KNID, title, date, reason). Log: `[{timestamp}] gc | {N} stale drafts flagged`.

---

## W4: Weekly Deep Analysis (Saturday 10:00)

**Procedure**:
1. Trend analysis: new-entry count, priority distribution, top-5 tags.
2. Relationship discovery: find unlinked entries with overlapping tags.
3. Graph reconstruction: update `tools/GRAPH.md` with new nodes and edges.
4. Gap analysis: infer missing prerequisite concepts.
5. Deep insight: synthesize 2–3 cross-domain connections.
6. Monthly report aggregation: at month end, aggregate daily reports → `tools/analysis/daily/summaries/{YYYY}-{MM}-summary.md`.
7. Publish weekly report to `tools/analysis/weekly/{YYYY}/{YYYY}-W{WW}-analysis.md`.
8. Log weekly maintenance to audit.

**Lint & Remediation (run after analysis)**:
9. **Contradiction scan**: Compare factual claims across all entries published this period. Flag contradictions in weekly report with `[CONFLICT] {KNID-A} vs {KNID-B}: {claim}`. Auto-remediate: append `#st-unverified` to both entries' tags.
10. **Index integrity check**: Count actual `###` headers in `knowledge/{YYYY}/{MM}.md` files; compare with INDEX.md total. Report discrepancy. Auto-remediate: update INDEX.md count if mismatch is verifiable (counted correctly).
11. **Expired status check**: Scan `knowledge/` entries for `#st-new` >30 days → flag for review in report. For `#st-unverified` >90 days → propose archival/deletion in report. Do NOT auto-delete — Scholar confirmation required.
12. **Orphan check**: Scan `knowledge/` entries for KNID with zero incoming `[[ ]]` references from other entries. List orphans in weekly report; suggest Related links if semantically connected.
13. **work/ stale check**: Cross-verify W3 step 6 GC results. Report any drafts still stale.
14. **Remediation report**: For each pathology found, state: (a) what was auto-fixed, (b) what requires Scholar review (actionable, with KNIDs and suggested fixes). Append to weekly report.
15. **Append to `tools/activity.log`**: `[{timestamp}] lint | {N} pathologies found | {M} auto-fixed | {P} flagged for review`.

---

## W5: Retrieval & Query-to-Archive (On-Demand)

**Trigger**: Scholar queries the knowledge base.

**Procedure**:
1. Parse the Scholar's query.
2. Navigate via S6 (Wiki Navigation Heuristics in STRATEGY.md): check KNID/title match → follow Related links → search INDEX.md by theme+tag → GRAPH.md context.
3. Read relevant entries from `knowledge/`, following `**Related**:` links.
4. Present synthesized answer with source citations.

**Query-to-archive (Art. XII.6)**:
5. After presenting the answer, evaluate: does this synthesis contain **novel analysis, comparison, framework, or insight** NOT already present in `knowledge/`?
6. If YES → offer to the Scholar: "这个分析要存为知识条目吗？" 
7. If Scholar confirms → execute W1 (Extraction) to create a draft entry in `work/`.
8. If NO or Scholar declines → no action. Log retrieval to activity.log only.

---

## W6: Sessio