# Audit Registry
> Monthly summaries. Raw logs in `logs/`. Digests in `digests/`.

| Month | Extractions | Consolidations | Amendments |
|-------|:-----------:|:--------------:|:----------:|
| (awaiting first month) | — | — | — |

**Stats**: 0 months | Last updated: (init)
