# Knowledge Graph
> Mermaid concept-relationship graph

```mermaid
graph LR
  subgraph Start
    A[P0-IDEA-HELO-0000000001: Hello World]
  end
```
