# Git 推送维护指南

> 当需要将知识库更新推送到 GitHub 时，按以下步骤操作。
> 本文件不纳入知识索引——纯运维参考。

## 远程仓库

```
https://github.com/Whoeverknow/academic-knowledge-manager.git
```

## 推送流程

```bash
cd F:\8-ClaudeKnowlegeBase\1-AcademicKnowledge
git add .
git status          # 确认没有不该提交的文件
git commit -m "<描述本次更新>"
git push origin main
```

## 网络代理

如果 push 失败（Connection reset），需要先配代理：

```bash
git config --global http.proxy http://127.0.0.1:7890
git config --global https.proxy http://127.0.0.1:7890
```

代理工具：flclash 0.8.92，默认端口 7890。如果端口变了，替换上面数字。

## 注意事项

- `.gitignore` 已配置排除个人数据，`git add .` 不会误提交
- push 前必须跑 `git status` 看一眼
- 不要提交 `memory/`、`conversations/nodes/`、审计日志、日报周报
